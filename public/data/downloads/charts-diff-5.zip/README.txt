maimai DX 谱面打包（预览站导出）

谱面数据来自 mai-charts（CNB）与 AWMC chart-preview API，宴谱来自落雪查分器。
文件为 maidata 格式文本，文件名格式：<曲名> [DX|ST] [难度].maidata.txt
难度编号：2=BASIC 3=ADVANCED 4=EXPERT 5=MASTER 6=RE:MASTER

生成时间：2026-11-03T12:46:01.312Z
站点：https://preview.baka86.love
